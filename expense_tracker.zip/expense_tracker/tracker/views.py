from django.shortcuts import render, redirect
from django.contrib import messages
from tracker.models import Transection
# Create your views here.

def index(request):
    
    if request.method == 'POST':
        description = request.POST.get('description')
        amount = request.POST.get('amount')
        
        # print(description, amount)
        
        if description is None:
            messages.info(request, "Descripion cannot be Blank")
            return redirect('/')

        try:
            amount = float(amount)
        except Exception as e:
            messages.info(request, 'please enter valid amount')
            return redirect('/')
        
        Transection.objects.create(
            description = description,
            amount = amount,
        )
        
        
        
        return redirect('/')
    context = {'transections' : Transection.objects.all(),
               'balance': Transection.objects.all().aaggregate(total_balance = sum(Transection.amount))['balance'] or 0,
               'income': Transection.objects.filter(amount__gte = 0).aaggregate(income = sum(Transection.amount))['income'] or 0,
               'expense': Transection.objects.filter(amount__lte = 0).aaggregate(expense = sum(Transection.amount))['expense'] or 0,
               } 
    return render(request, 'index.html',context)